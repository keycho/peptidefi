biohash-oracle-lab — pricing-reality cinematic mode
====================================================

DROP-IN INSTALL
---------------
  cd /Users/conradlitchfield/biohash-oracle-lab
  unzip -o ~/Downloads/biohash-pricing-reality.zip

This will:
  - create src/camera/ + src/scenes/ + src/modes/ (new dirs)
  - write src/camera/camera.js, src/scenes/pricing-reality-scenes.js,
          src/modes/pricing-reality.js (new files)
  - REPLACE src/main.js (only delta: a 5-line ?mode dispatch block —
          all other code byte-identical to your existing main.js)

WHAT'S UNCHANGED
----------------
  index.html, src/style.js, src/animation.js, src/render-frame.js,
  src/data-loader.js, src/panels/panel-cycle-stream.js,
  src/panels/panel-cross-peptide.js, data/oracle-snapshot.json
  → default mode (no ?mode= param) is byte-identical.

RUN
---
  python3 -m http.server 8000
  open http://localhost:8000/                              (default mode, unchanged)
  open http://localhost:8000/?mode=pricing-reality         (40s cinematic)
  open http://localhost:8000/?mode=pricing-reality&t=24    (seek to 24s)
  open http://localhost:8000/?mode=pricing-reality&t=24&paused=1  (freeze)

KEYS
----
  Space  pause/resume
  R      restart
  ←/→    scrub ±1s
  0      seek to start
